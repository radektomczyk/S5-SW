#include <targets/AT91SAM7.h>
#define AUDIO_OUT PIOB_SODR_P19
#define SW_1 PIOB_SODR_P24

void czas(int ms){
volatile int a,b;
	for(a=0;a<=ms;a++){
	for(b=0;b<=3;b++){
		__asm__("NOP");
	}}}

int main (void){
  PMC_PCER = 1<<3;//za��czenie zegara systemowego do wybranego peryferium (w tym przypadku PIOB).  Zapoznad si� z rozdzia�em 25.5 str. 173 oraz peripheral identifiers str. 30
  PIOB_PER = 1<<19;
  PIOB_OER = 1<<19;
  PIOB_PER = 1<<20;//za��czenie kontrolikontrolera  I/Onad  wybranym  PINem �w  tym  przypadku  PIN 65 b�dzie kontrolowany przez lini� 20 kontorlera I/O B  27.4.2
  PIOB_PER |= 1<<24;// j.w.
  PIOB_OER = 1<<20;// linia 20 portu B pracuje jako wyj�cie 27.4.4
  PIOB_ODR = 1<<24;// linia 24 portu B pracuje jako wej�ciowa  27.4.4
  PIOB_SODR = 1<<20;// stan linii 20 portu B ustawiony na 1 (na PINie 65 ustawiony zosta� stan wysoki) 
  while(1){ //p�tla nieskooczona tak, by program oczekiwa� na wci�ni�cie przycisku
    //if ( ( PIOB_PDSR & 1<<24 ) == 0 ){// sprawdzenie stanu linii 24 Portu B (PIN 70), je�lina  linii  24  jest stan wysoki �na bicie 24 rejestru PDSR pojawia si� 1, je�li stan jest linii jest niski �na bicie pojawia si� 0
      //PIOB_CODR = 1<<20;// stan linii 20 portu B ustawiony na 1 (na PINie 65 ustawiony zosta� stan niski)
    //} 
    
    /*if ( ( PIOB_PDSR & 1<<24 ) == 0 ){// sprawdzenie stanu linii 24 Portu B (PIN 70), je�lina  linii  24  jest stan wysoki �na bicie 24 rejestru PDSR pojawia si� 1, je�li stan jest linii jest niski �na bicie pojawia si� 0
      PIOB_SODR = 1<<19;
      czas(5);
      PIOB_CODR = 1<<19;
      czas(5);
    } /*
    if ( ( PIOB_PDSR & 1<<25 ) == 0 ){// sprawdzenie stanu linii 24 Portu B (PIN 70), je�lina  linii  24  jest stan wysoki �na bicie 24 rejestru PDSR pojawia si� 1, je�li stan jest linii jest niski �na bicie pojawia si� 0
      PIOB_SODR = 1<<19;
      czas(5);
      PIOB_CODR = 1<<19;
      czas(5);
    } */
    if ( ( PIOB_PDSR & 1<<24 ) == 0 ){// sprawdzenie stanu linii 24 Portu B (PIN 70), je�lina  linii  24  jest stan wysoki �na bicie 24 rejestru PDSR pojawia si� 1, je�li stan jest linii jest niski �na bicie pojawia si� 0
      for(int i = 250; i>0; i--){
        PIOB_SODR = 1<<19;
        czas(i*3);
        PIOB_CODR = 1<<19;
        czas(5);
      }
    } 
    if ( ( PIOB_PDSR & 1<<25 ) == 0 ){// sprawdzenie stanu linii 24 Portu B (PIN 70), je�lina  linii  24  jest stan wysoki �na bicie 24 rejestru PDSR pojawia si� 1, je�li stan jest linii jest niski �na bicie pojawia si� 0
      for(int i = 160; i>0; i--){
        PIOB_SODR = 1<<19;
        czas(i*2);
        PIOB_CODR = 1<<19;
        czas(5);
      }
    } 
      
    
  }
}